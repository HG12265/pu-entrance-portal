-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: db    Database: periyar_entrance_exam
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_admins_username` (`username`),
  KEY `ix_admins_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admins`
--

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
INSERT INTO `admins` VALUES (1,'admin','$pbkdf2-sha256$29000$J4TwPqf0PscY47z33junVA$3JlfuhELS0BP4iIQtE2NCt22jNQbcHCJB.H.dKWjA9k','Periyar Admin'),(2,'periyar_admin','$pbkdf2-sha256$29000$SGkNwVjL2RtDaG3tfY/xfg$UjU76wNN4nuEos8wKTq.kbuq/S/tsG8XWHuEDv6AE2U','Periyar Admin');
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admission_confirmations`
--

DROP TABLE IF EXISTS `admission_confirmations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admission_confirmations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `candidate_id` int NOT NULL,
  `course_id` int NOT NULL,
  `confirmed_by_admin_id` int DEFAULT NULL,
  `confirmed_at` datetime DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  KEY `candidate_id` (`candidate_id`),
  KEY `course_id` (`course_id`),
  KEY `confirmed_by_admin_id` (`confirmed_by_admin_id`),
  KEY `ix_admission_confirmations_id` (`id`),
  CONSTRAINT `admission_confirmations_ibfk_1` FOREIGN KEY (`candidate_id`) REFERENCES `candidates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `admission_confirmations_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `admission_confirmations_ibfk_3` FOREIGN KEY (`confirmed_by_admin_id`) REFERENCES `admins` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admission_confirmations`
--

LOCK TABLES `admission_confirmations` WRITE;
/*!40000 ALTER TABLE `admission_confirmations` DISABLE KEYS */;
/*!40000 ALTER TABLE `admission_confirmations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `candidates`
--

DROP TABLE IF EXISTS `candidates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `candidates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `mobile_number` varchar(20) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `community` varchar(50) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `raw_common_details_json` text,
  `has_verified_details` tinyint(1) DEFAULT NULL,
  `verified_at` datetime DEFAULT NULL,
  `admitted_course_id` int DEFAULT NULL,
  `admission_confirmed_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `admitted_course_id` (`admitted_course_id`),
  KEY `ix_candidates_id` (`id`),
  KEY `ix_candidates_mobile_number` (`mobile_number`),
  CONSTRAINT `candidates_ibfk_1` FOREIGN KEY (`admitted_course_id`) REFERENCES `courses` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=950 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `candidates`
--

LOCK TABLES `candidates` WRITE;
/*!40000 ALTER TABLE `candidates` DISABLE KEYS */;
/*!40000 ALTER TABLE `candidates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_community_seats`
--

DROP TABLE IF EXISTS `course_community_seats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `course_community_seats` (
  `id` int NOT NULL AUTO_INCREMENT,
  `course_id` int NOT NULL,
  `community_code` varchar(50) NOT NULL,
  `community_name` varchar(100) NOT NULL,
  `seat_count` int NOT NULL,
  `display_order` int NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `_course_community_uc` (`course_id`,`community_code`),
  KEY `ix_course_community_seats_id` (`id`),
  CONSTRAINT `course_community_seats_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_community_seats`
--

LOCK TABLES `course_community_seats` WRITE;
/*!40000 ALTER TABLE `course_community_seats` DISABLE KEYS */;
INSERT INTO `course_community_seats` VALUES (1,1,'OC','Open Competition',9,1,'2026-06-24 04:07:49','2026-06-24 04:07:49'),(2,1,'BC','Backward Class',8,2,'2026-06-24 04:07:49','2026-06-24 04:07:49'),(3,1,'BCM','Backward Class Muslim',1,3,'2026-06-24 04:07:49','2026-06-24 04:07:49'),(4,1,'MBC','Most Backward Class',6,4,'2026-06-24 04:07:49','2026-06-24 04:07:49'),(5,1,'SC','Scheduled Caste',4,5,'2026-06-24 04:07:49','2026-06-24 04:07:49'),(6,1,'SCA','Scheduled Caste Arunthathiyar',1,6,'2026-06-24 04:07:49','2026-06-24 04:07:49'),(7,1,'ST','Scheduled Tribe',1,7,'2026-06-24 04:07:49','2026-06-24 04:07:49'),(8,2,'OC','Open Competition',14,1,'2026-06-24 04:07:49','2026-06-24 04:07:49'),(9,2,'BC','Backward Class',12,2,'2026-06-24 04:07:49','2026-06-24 04:07:49'),(10,2,'BCM','Backward Class Muslim',2,3,'2026-06-24 04:07:49','2026-06-24 04:07:49'),(11,2,'MBC','Most Backward Class',9,4,'2026-06-24 04:07:49','2026-06-24 04:07:49'),(12,2,'SC','Scheduled Caste',5,5,'2026-06-24 04:07:49','2026-06-24 04:07:49'),(13,2,'SCA','Scheduled Caste Arunthathiyar',1,6,'2026-06-24 04:07:49','2026-06-24 04:07:49'),(14,2,'ST','Scheduled Tribe',1,7,'2026-06-24 04:07:49','2026-06-24 04:07:49'),(15,3,'OC','Open Competition',14,1,'2026-06-24 04:07:49','2026-06-24 04:07:49'),(16,3,'BC','Backward Class',12,2,'2026-06-24 04:07:49','2026-06-24 04:07:49'),(17,3,'BCM','Backward Class Muslim',2,3,'2026-06-24 04:07:49','2026-06-24 04:07:49'),(18,3,'MBC','Most Backward Class',9,4,'2026-06-24 04:07:49','2026-06-24 04:07:49'),(19,3,'SC','Scheduled Caste',5,5,'2026-06-24 04:07:49','2026-06-24 04:07:49'),(20,3,'ST','Scheduled Tribe',1,7,'2026-06-24 04:07:49','2026-06-24 04:07:49'),(21,3,'SCA','Scheduled Caste Arunthathiyar',1,6,'2026-06-24 04:07:49','2026-06-24 04:07:49');
/*!40000 ALTER TABLE `course_community_seats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `courses`
--

DROP TABLE IF EXISTS `courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `courses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `seat_count` int DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_courses_code` (`code`),
  KEY `ix_courses_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `courses`
--

LOCK TABLES `courses` WRITE;
/*!40000 ALTER TABLE `courses` DISABLE KEYS */;
INSERT INTO `courses` VALUES (1,'MCA','Master of Computer Applications',30,1,'2026-06-24 04:07:49'),(2,'MSC_CS','M.Sc Computer Science',44,1,'2026-06-24 04:07:49'),(3,'MSC_DS','M.Sc Data Science',44,1,'2026-06-24 04:07:49');
/*!40000 ALTER TABLE `courses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exam_attempt_event_logs`
--

DROP TABLE IF EXISTS `exam_attempt_event_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `exam_attempt_event_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `attempt_id` int NOT NULL,
  `candidate_id` int NOT NULL,
  `event_type` varchar(50) NOT NULL,
  `event_message` varchar(500) NOT NULL,
  `metadata_json` text,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `attempt_id` (`attempt_id`),
  KEY `candidate_id` (`candidate_id`),
  KEY `ix_exam_attempt_event_logs_id` (`id`),
  CONSTRAINT `exam_attempt_event_logs_ibfk_1` FOREIGN KEY (`attempt_id`) REFERENCES `exam_attempts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `exam_attempt_event_logs_ibfk_2` FOREIGN KEY (`candidate_id`) REFERENCES `candidates` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20499 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exam_attempt_event_logs`
--

LOCK TABLES `exam_attempt_event_logs` WRITE;
/*!40000 ALTER TABLE `exam_attempt_event_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `exam_attempt_event_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exam_attempts`
--

DROP TABLE IF EXISTS `exam_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `exam_attempts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `candidate_id` int NOT NULL,
  `exam_id` int NOT NULL,
  `started_at` datetime DEFAULT NULL,
  `submitted_at` datetime DEFAULT NULL,
  `total_questions` int DEFAULT NULL,
  `correct_answers` int DEFAULT NULL,
  `wrong_answers` int DEFAULT NULL,
  `score` float DEFAULT NULL,
  `percentage` float DEFAULT NULL,
  `is_submitted` tinyint(1) DEFAULT NULL,
  `is_disqualified` tinyint(1) DEFAULT '0',
  `question_order_json` text,
  `status` varchar(50) NOT NULL,
  `violation_count` int NOT NULL,
  `submitted_reason` varchar(500) DEFAULT NULL,
  `submit_source` varchar(100) DEFAULT NULL,
  `elapsed_seconds_at_submit` int NOT NULL,
  `reopened_by_admin_id` int DEFAULT NULL,
  `reopened_at` datetime DEFAULT NULL,
  `reopen_reason` varchar(500) DEFAULT NULL,
  `reopen_count` int NOT NULL,
  `last_activity_at` datetime DEFAULT NULL,
  `current_question_index` int DEFAULT NULL,
  `time_extension_minutes` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `_candidate_exam_attempt_uc` (`candidate_id`,`exam_id`),
  KEY `exam_id` (`exam_id`),
  KEY `reopened_by_admin_id` (`reopened_by_admin_id`),
  KEY `ix_exam_attempts_id` (`id`),
  CONSTRAINT `exam_attempts_ibfk_1` FOREIGN KEY (`candidate_id`) REFERENCES `candidates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `exam_attempts_ibfk_2` FOREIGN KEY (`exam_id`) REFERENCES `exams` (`id`) ON DELETE CASCADE,
  CONSTRAINT `exam_attempts_ibfk_3` FOREIGN KEY (`reopened_by_admin_id`) REFERENCES `admins` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=364 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exam_attempts`
--

LOCK TABLES `exam_attempts` WRITE;
/*!40000 ALTER TABLE `exam_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `exam_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exams`
--

DROP TABLE IF EXISTS `exams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `exams` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `total_questions` int DEFAULT NULL,
  `duration_minutes` int DEFAULT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `result_visibility` tinyint(1) DEFAULT NULL,
  `start_at_utc` datetime DEFAULT NULL,
  `end_at_utc` datetime DEFAULT NULL,
  `timezone` varchar(100) NOT NULL,
  `schedule_mode` varchar(50) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_exams_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exams`
--

LOCK TABLES `exams` WRITE;
/*!40000 ALTER TABLE `exams` DISABLE KEYS */;
INSERT INTO `exams` VALUES (1,'Periyar University Entrance Examination 2026',100,120,'2026-06-24 08:36:00','2026-06-24 10:36:00',1,'2026-06-24 08:36:00','2026-06-24 10:36:00','Asia/Kolkata','FIXED_WINDOW','2026-06-24 04:07:49');
/*!40000 ALTER TABLE `exams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `import_batches`
--

DROP TABLE IF EXISTS `import_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `import_batches` (
  `id` int NOT NULL AUTO_INCREMENT,
  `course_id` int NOT NULL,
  `filename` varchar(255) NOT NULL,
  `uploaded_by_admin_id` int DEFAULT NULL,
  `total_rows` int DEFAULT NULL,
  `inserted_count` int DEFAULT NULL,
  `updated_count` int DEFAULT NULL,
  `skipped_count` int DEFAULT NULL,
  `error_count` int DEFAULT NULL,
  `errors_json` text,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `course_id` (`course_id`),
  KEY `uploaded_by_admin_id` (`uploaded_by_admin_id`),
  KEY `ix_import_batches_id` (`id`),
  CONSTRAINT `import_batches_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `import_batches_ibfk_2` FOREIGN KEY (`uploaded_by_admin_id`) REFERENCES `admins` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `import_batches`
--

LOCK TABLES `import_batches` WRITE;
/*!40000 ALTER TABLE `import_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `import_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `questions`
--

DROP TABLE IF EXISTS `questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `questions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `exam_id` int NOT NULL,
  `question_text` text NOT NULL,
  `option_a` varchar(255) NOT NULL,
  `option_b` varchar(255) NOT NULL,
  `option_c` varchar(255) NOT NULL,
  `option_d` varchar(255) NOT NULL,
  `correct_option` varchar(10) NOT NULL,
  `marks` float DEFAULT NULL,
  `image_url` varchar(500) DEFAULT NULL,
  `option_a_image_url` varchar(500) DEFAULT NULL,
  `option_b_image_url` varchar(500) DEFAULT NULL,
  `option_c_image_url` varchar(500) DEFAULT NULL,
  `option_d_image_url` varchar(500) DEFAULT NULL,
  `part_code` varchar(50) DEFAULT NULL,
  `part_name` varchar(255) DEFAULT NULL,
  `part_order` int DEFAULT NULL,
  `source_s_no` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exam_id` (`exam_id`),
  KEY `ix_questions_id` (`id`),
  CONSTRAINT `questions_ibfk_1` FOREIGN KEY (`exam_id`) REFERENCES `exams` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=401 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `questions`
--

LOCK TABLES `questions` WRITE;
/*!40000 ALTER TABLE `questions` DISABLE KEYS */;
/*!40000 ALTER TABLE `questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_answers`
--

DROP TABLE IF EXISTS `student_answers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student_answers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `attempt_id` int NOT NULL,
  `question_id` int NOT NULL,
  `selected_option` varchar(10) DEFAULT NULL,
  `is_correct` tinyint(1) DEFAULT NULL,
  `marks_obtained` float DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `_attempt_question_uc` (`attempt_id`,`question_id`),
  KEY `question_id` (`question_id`),
  KEY `ix_student_answers_id` (`id`),
  CONSTRAINT `student_answers_ibfk_1` FOREIGN KEY (`attempt_id`) REFERENCES `exam_attempts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `student_answers_ibfk_2` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=35003 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_answers`
--

LOCK TABLES `student_answers` WRITE;
/*!40000 ALTER TABLE `student_answers` DISABLE KEYS */;
/*!40000 ALTER TABLE `student_answers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_applications`
--

DROP TABLE IF EXISTS `student_applications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student_applications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `candidate_id` int NOT NULL,
  `course_id` int NOT NULL,
  `application_number` varchar(100) NOT NULL,
  `mobile_number` varchar(20) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `community` varchar(50) DEFAULT NULL,
  `ug_marks` float DEFAULT NULL,
  `raw_details_json` text,
  `import_batch_id` int DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `_candidate_course_uc` (`candidate_id`,`course_id`),
  UNIQUE KEY `ix_student_applications_application_number` (`application_number`),
  KEY `course_id` (`course_id`),
  KEY `import_batch_id` (`import_batch_id`),
  KEY `ix_student_applications_id` (`id`),
  KEY `ix_student_applications_mobile_number` (`mobile_number`),
  CONSTRAINT `student_applications_ibfk_1` FOREIGN KEY (`candidate_id`) REFERENCES `candidates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `student_applications_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `student_applications_ibfk_3` FOREIGN KEY (`import_batch_id`) REFERENCES `import_batches` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=972 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_applications`
--

LOCK TABLES `student_applications` WRITE;
/*!40000 ALTER TABLE `student_applications` DISABLE KEYS */;
/*!40000 ALTER TABLE `student_applications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'periyar_entrance_exam'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-24  9:59:43
